import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from mpl_toolkits.axes_grid1.inset_locator import mark_inset
num=1


account_growth_min=np.load("min.npy")
account_growth_mean=np.load("mean.npy")
account_growth_min=account_growth_min[0:1190]
account_growth_mean=account_growth_mean[0:1190]

account_growth = np.loadtxt('DJIA.txt');
origi_asmemory = np.loadtxt('DDPG.txt');
asmemory= np.loadtxt("Adaptive DDPG.txt");
account_growth=account_growth[0:1190]/10


fig=plt.figure(figsize=(15,5))



font1 = {'weight' : 'semibold',
'size'   : 20,
}
plt.xlabel("Date",font1)
plt.ylabel("Portfolio Value",font1)

x=np.array([0.,  150.,  300.,  450., 600., 750.,  900., 1050.,1200.])
y=np.array([9000.,  11000.,  13000.,  15000., 17000., 19000.,21000.,23000])
group_labels=['01/02/2014','08/11/2014', '03/20/2015','10/30/2015', '05/09/2016',
              '12/19/2016', '07/27/2017','03/01/2018', '10/02/2018']
plt.xticks(x,group_labels,fontsize=14,)
plt.yticks(fontsize=14,)
plt.grid(linestyle="--")
plt.xlim(0, 1200)
plt.ylim(9000, 23000)


plt.plot(asmemory,color="hotpink",label="Adaptive DDPG ")
plt.plot(origi_asmemory,color="cornflowerblue",label="DDPG ")
plt.plot(account_growth,color="deepskyblue",label="DJIA")
plt.plot(account_growth_min,color="black",linestyle = "--",label="Min-Var ")
plt.plot(account_growth_mean,color="red",linestyle = "--",label="Mean-Var ")
plt.legend(loc='upper left',fontsize=16)
plt.savefig('E:/Anaconda3/envs/tensorflow/Lib/site-packages/gym/envs/portfolio/Data_Daily_Stock_Dow_Jones_30/DQN/figure_{}.pdf'.format(num),bbox_inches='tight')
plt.show()
plt.close()

normalized_market_diff = np.ones([4400,1])*16000
normalized_market_diff[3268+395:3268+425] = 14000
normalized_market_diff[3268+490:3268+525] = 14000
normalized_market_diff[3268+650:3268+680] = 14000
normalized_market_diff[3268+1010:3268+1050] = 14000
data_market = pd.read_csv('E:/Anaconda3/envs/tensorflow/Lib/site-packages/gym/envs/zxstock/Data_Daily_Stock_Dow_Jones_30/DJI_market.csv')
dji_ = data_market.Adj_Close
normalized_market_diff[4390:4500]=None
dji_[4390:4500]=None
x=np.array([3200.,     3500.,   3800.,    4100.,  4400.])
group_labels=['01/02/2014', '03/20/2015', '05/09/2016',
             '07/27/2017', '10/02/2018']


fig=plt.figure(figsize=(7.7,2.5))
plt.xticks(x,group_labels,fontsize=14,)
plt.yticks(fontsize=14, )
plt.grid(linestyle="--")
plt.xlim(3200, 4400)
plt.ylim(14000, 27000)
plt.plot(dji_,color="r",label="Market Index ",linewidth=1.5)
plt.plot(normalized_market_diff,color="cornflowerblue",label="Learning rate",linewidth=3)
font2 = {
'weight' : 'semibold',
'size'   : 14,
}
# 'family' : 'Times New Roman',
plt.xlabel("Date",font2)
plt.ylabel("Price",font2)
plt.legend(loc='upper left',fontsize=12)
plt.savefig('E:/Anaconda3/envs/tensorflow/Lib/site-packages/gym/envs/zxstock/Data_Daily_Stock_Dow_Jones_30/DQN/Figureb_{}.pdf'.format(num),bbox_inches='tight')
plt.show()

